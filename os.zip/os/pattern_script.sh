#!/bin/bash

# Function to print number pattern
print_number_pattern() {
    local n=$1

    # Loop to print increasing number pattern
    for (( i = 1; i <= n; i++ )); do
        for (( j = 1; j <= i; j++ )); do
            echo -n "$j "
        done
        echo ""
    done

    # Loop to print decreasing number pattern
    for (( i = n-1; i >= 1; i-- )); do
        for (( j = 1; j <= i; j++ )); do
            echo -n "$j "
        done
        echo ""
    done
}

# Function to print asterisk pattern
print_asterisk_pattern() {
    local n=$1

    # Loop to print asterisk pattern
    for (( i = 1; i <= n; i++ )); do
        for (( j = 1; j <= i; j++ )); do
            echo -n "* "
        done
        echo ""
    done

    # Loop to print reverse asterisk pattern
    for (( i = n-1; i >= 1; i-- )); do
        for (( j = 1; j <= i; j++ )); do
            echo -n "* "
        done
        echo ""
    done
}

# Main program flow
echo "Enter a number:"
read n

echo "Number Pattern:"
print_number_pattern $n

echo "Asterisk Pattern:"
print_asterisk_pattern $n

