#!/bin/bash
echo "Please enter the full path of the file:"
read file_path

echo "Please enter the new name for the file:"
read new_name

# Extract directory path
dir_path=$(dirname "$file_path")

# Combine directory path with new name
new_path="$dir_path/$new_name"

if [ -f "$file_path" ]; then
    mv "$file_path" "$new_path"
    echo "File renamed to '$new_path'."
    echo "Content of the file:"
    cat "$new_path"
else
    echo "File does not exist."
fi

