




echo "please enter you name:"
read name
echo "Hello, $name!"
