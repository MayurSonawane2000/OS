#!/bin/bash

# Function to check if a number is prime
is_prime() {
    local num=$1
    local isPrime=true

    if [ $num -le 1 ]; then
        isPrime=false
    fi

    for (( i = 2; i * i <= num; i++ )); do
        if [ $(( num % i )) -eq 0 ]; then
            isPrime=false
            break
        fi
    done

    if $isPrime; then
        echo "$num is a prime number."
    else
        echo "$num is not a prime number."
    fi
}

# Main program flow
echo "Enter a number:"
read number

# Call is_prime function with user input
is_prime $number

