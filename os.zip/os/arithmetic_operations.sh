#!/bin/bash
echo "Enter the first number:"
read num1

echo "Enter the second number:"
read num2

sum=`expr $num1 + $num2`
diff=`expr $num1 - $num2`
prod=`expr $num1 \* $num2`
quotient=`expr $num1 / $num2`
remainder=`expr $num1 % $num2`

echo "Sum: $sum"
echo "Difference: $diff"
echo "Product: $prod"
echo "Quotient: $quotient"
echo "Remainder: $remainder"

