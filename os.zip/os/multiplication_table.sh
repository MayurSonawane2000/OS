#!/bin/bash

# Function to display multiplication table
multiplication_table() {
    local num=$1

    echo "Multiplication table of $num:"

    for (( i = 1; i <= 10; i++ )); do
        echo "$num * $i = $((num * i))"
    done
}

# Main program flow
echo "Enter a number:"
read number

# Call multiplication_table function with user input
multiplication_table $number

