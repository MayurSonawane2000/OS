#!/bin/bash

# Script to add student data to a file

# Prompt user for student information
echo "Enter student ID:"
read id

echo "Enter student Name:"
read name

echo "Enter student Marks:"
read marks

# Append student data to file
echo "$id $name $marks" >> studentdata

echo "Student data added successfully."

