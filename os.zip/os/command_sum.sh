#!/bin/bash

sum=0

# Loop through all command-line arguments
for a in "$@"
do
   sum=$(echo "$sum + $a" | bc)
done

echo "Sum = $sum"

