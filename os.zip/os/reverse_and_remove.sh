#!/bin/bash
echo "Please enter the path of the file along with its name:"
read file_path

if [ -f "$file_path" ]; then
    echo "Content of the file in reverse order:"
    tac "$file_path"

    echo "Removing the file..."
    rm "$file_path"
    echo "File removed."
else
    echo "File does not exist."
fi

