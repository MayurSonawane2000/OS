#!/bin/bash

# Infinite loop to accept numbers until "quit" is entered
while true
do
  echo "Enter a number (enter 'quit' to exit):"
  read input

  # Check if user wants to quit
  if [ "$input" = "quit" ]
  then
    break
  fi

  # Append input to the file 'myvalues'
  echo "$input" >> myvalues
done

# Sort the numbers in 'myvalues' file numerically and display them
echo "Sorted numbers:"
sort -n myvalues

# Optionally, you can remove the file after sorting
# rm myvalues

