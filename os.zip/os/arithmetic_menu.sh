#!/bin/bash

# Function to display the menu and perform operations
arithmetic_menu() {
    echo "Select an operation:"
    echo "1. Add"
    echo "2. Subtract"
    echo "3. Multiply"
    echo "4. Divide"
    echo "5. Exit"
    
    read choice

    case $choice in
        1)
            echo "Enter first number:"
            read num1
            echo "Enter second number:"
            read num2
            result=$(echo "$num1 + $num2" | bc)
            echo "Result: $result"
            ;;
        2)
            echo "Enter first number:"
            read num1
            echo "Enter second number:"
            read num2
            result=$(echo "$num1 - $num2" | bc)
            echo "Result: $result"
            ;;
        3)
            echo "Enter first number:"
            read num1
            echo "Enter second number:"
            read num2
            result=$(echo "$num1 * $num2" | bc)
            echo "Result: $result"
            ;;
        4)
            echo "Enter first number:"
            read num1
            echo "Enter second number:"
            read num2
            if [ "$num2" == "0" ]; then
                echo "Error: Division by zero is not allowed."
            else
                result=$(echo "scale=2; $num1 / $num2" | bc)
                echo "Result: $result"
            fi
            ;;
        5)
            echo "Exiting..."
            exit 0
            ;;
        *)
            echo "Invalid choice. Please select a valid option."
            ;;
    esac
}

# Main program loop
while true; do
    arithmetic_menu
done

