
echo "Please enter the name for the folder:"
read folder_name
mkdir "$folder_name"
echo "Folder '$folder_name' created."
echo "Contents of the current directory:"
ls

