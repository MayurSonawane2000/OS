#!/bin/bash

# Function to validate email using regex
validate_email() {
    email=$1
    regex="^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$"
    if [[ $email =~ $regex ]]; then
        echo "Valid email: $email"
    else
        echo "Invalid email: $email"
    fi
}

# Main script
echo "Enter an email address:"
read user_email

validate_email "$user_email"

