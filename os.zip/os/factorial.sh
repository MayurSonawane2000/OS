#!/bin/bash

# Function to calculate factorial
factorial() {
    local num=$1
    local result=1

    for (( i = 1; i <= num; i++ )); do
        result=$((result * i))
    done

    echo "The factorial of $num is $result."
}

# Main program flow
echo "Enter a number:"
read number

# Call factorial function with user input
factorial $number

